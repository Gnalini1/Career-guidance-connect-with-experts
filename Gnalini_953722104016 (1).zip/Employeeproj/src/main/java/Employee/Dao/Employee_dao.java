package Employee.Dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Employee.controller.DBUtil;
import package_employee.been.Employee_been;

public class Employee_dao {

    // Validate login
    public static String validateLogin(String email, String password) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT name FROM employees WHERE email=? AND password=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("name");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Register new user
    public static boolean register(String name, String email, String password, String dept) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "INSERT INTO employees (name, email, password, department) VALUES (?, ?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, dept);
            ps.executeUpdate();
            return true;
        } catch (SQLIntegrityConstraintViolationException e) {
            return false; // Duplicate email
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Forgot password: get password by email
    public static String getPasswordByEmail(String email) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT password FROM employees WHERE email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return rs.getString("password");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Update employee details
    public static boolean updateEmployee(String originalEmail, Employee_been emp) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "UPDATE employees SET name=?, email=?, password=?, department=? WHERE email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, emp.getName());
            ps.setString(2, emp.getEmail());
            ps.setString(3, emp.getPassword());
            ps.setString(4, emp.getDepartment());
            ps.setString(5, originalEmail);
            int rows = ps.executeUpdate();
            return rows > 0;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Check if email already exists
    public static boolean isEmailTaken(String email) {
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT email FROM employees WHERE email=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            return rs.next();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Get all employees
    public static List<Employee_been> getAllEmployees() {
        List<Employee_been> list = new ArrayList<>();
        try (Connection con = DBUtil.getConnection()) {
            String sql = "SELECT * FROM employees";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Employee_been emp = new Employee_been();
                emp.setName(rs.getString("name"));
                emp.setEmail(rs.getString("email"));
                emp.setPassword(rs.getString("password")); // optional
                emp.setDepartment(rs.getString("department"));
                list.add(emp);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}