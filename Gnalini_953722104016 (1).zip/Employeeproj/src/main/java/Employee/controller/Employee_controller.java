package Employee.controller;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.util.List;

import Employee.Dao.Employee_dao;
import package_employee.been.Employee_been;

public class Employee_controller extends HttpServlet {

    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("login".equalsIgnoreCase(action)) {
            login(req, res);
        } else if ("register".equalsIgnoreCase(action)) {
            register(req, res);
        } else if ("forgot".equalsIgnoreCase(action)) {
            forgot(req, res);
        } else if ("editForm".equalsIgnoreCase(action)) {
            showEditForm(req, res);
        } else if ("update".equalsIgnoreCase(action)) {
            updateEmployee(req, res);
        } else {
            res.getWriter().println("Unknown action!");
        }
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");

        if ("editForm".equalsIgnoreCase(action)) {
            showEditForm(req, res); // ✅ This enables Modify to work
        } else {
            res.sendRedirect("login.jsp"); // fallback
        }
    }

    private void login(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {

        String email = req.getParameter("email");
        String password = req.getParameter("password");

        String name = Employee_dao.validateLogin(email, password);

        if (name != null) {
            HttpSession session = req.getSession();
            session.setAttribute("name", name);
            res.sendRedirect("Home.jsp");
        } else {
            req.setAttribute("error", "Invalid login!");
            req.getRequestDispatcher("login.jsp").forward(req, res);
        }
    }

    private void register(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {

        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String dept = req.getParameter("department");

        if (Employee_dao.isEmailTaken(email)) {
            req.setAttribute("error", "Email already registered!");
            req.getRequestDispatcher("register.jsp").forward(req, res);
        } else {
            boolean success = Employee_dao.register(name, email, password, dept);
            if (success) {
                res.sendRedirect("login.jsp");
            } else {
                req.setAttribute("error", "Registration failed");
                req.getRequestDispatcher("register.jsp").forward(req, res);
            }
        }
    }

    private void forgot(HttpServletRequest req, HttpServletResponse res)
            throws IOException, ServletException {

        String email = req.getParameter("email");
        String password = Employee_dao.getPasswordByEmail(email);

        if (password != null) {
            req.setAttribute("message", "Your password is: " + password);
        } else {
            req.setAttribute("message", "Email not found!");
        }

        req.getRequestDispatcher("forgot.jsp").forward(req, res);
    }

    // ✅ This must be inside the class
    private void showEditForm(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        List<Employee_been> all = Employee_dao.getAllEmployees();

        for (Employee_been emp : all) {
            if (emp.getEmail().equals(email)) {
                req.setAttribute("employee", emp);
                req.getRequestDispatcher("modify.jsp").forward(req, res);
                return;
            }
        }
        res.sendRedirect("Home.jsp");
    }

    // ✅ This must also be inside the class
    private void updateEmployee(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String originalEmail = req.getParameter("originalEmail");
        String name = req.getParameter("name");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String dept = req.getParameter("department");

        Employee_been emp = new Employee_been(name, email, password, dept);
        boolean success = Employee_dao.updateEmployee(originalEmail, emp);

        if (success) {
            res.sendRedirect("Home.jsp");
        } else {
            req.setAttribute("error", "Update failed!");
            req.setAttribute("employee", emp);
            req.getRequestDispatcher("modify.jsp").forward(req, res);
        }
    }
}